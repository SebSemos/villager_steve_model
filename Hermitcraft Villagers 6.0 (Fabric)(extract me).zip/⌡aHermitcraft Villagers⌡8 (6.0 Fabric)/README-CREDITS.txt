Please find all the information on what sources I used to create this pack and what mods it is dependant from, as well as instruction to customize it here:

https://github.com/SebSemos/villager_steve_model